<?php
    require_once "config.php";

    $kas_keluar = new App\KasKeluar();
    $rows = $kas_keluar->index();

    if (isset($_POST['hapus'])) {
        $kas_keluar->delete();
        header("location:index.php?page=index_kas_keluar");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 900px">
        <div class="card-title">Data Kas Keluar</div>
        <a href="index.php?page=tambah_kas_keluar">
            <button class="btn btn-success">Tambah</button>
        </a>
        <p></p>
        <table>
            <tr>
                <th>Judul</th>
                <th>Jenis</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($rows as $row) { ?>
            <tr>
                <td><?php echo $row['nama'] ?></td>
                <td><?php echo $kas_keluar->getKategori($row['kategori_id']) ?></td>
                <td style="width: 25%">
                <a href="index.php?page=edit_kas_keluar&id=<?php echo $row['id']?>">
                    <button class="btn btn-warning">Edit</button>
                </a>
                <form method="POST" style="display: inline">
                    <input type="text" name="id" value="<?php echo $row['id'] ?>" style="display:none">
                    <button class="btn btn-danger" name="hapus">Hapus</button>
                </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>