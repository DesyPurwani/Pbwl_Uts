<?php
    require_once "config.php";
    $kategori = new App\Kategori();
    $data_kategori = $kategori->index();
    
    if (isset($_POST['simpan'])) {
        $kas_masuk = new App\KasMasuk();
        $kas_masuk->insert();
        header("location:index.php?page=index_kas_masuk");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data Kas Masuk</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Nama</label>
                <input type="text" name="nama">
            </div>
            <div class="form-group">
                <label for="">Jenis/Kategori</label>
                <select name="kategori_id" id="">
                    <option value="">-Silahkan Pilih-</option>
                    <?php foreach($data_kategori as $item) { ?>
                    <option value="<?php echo $item['id'] ?>"><?php echo $item['nama'] ?></option>
                    <?php } ?>
                </select>
            </div>
            <input type="text" style="display: none" name="user_id" value="<?php echo $_SESSION['id'] ?>">
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>