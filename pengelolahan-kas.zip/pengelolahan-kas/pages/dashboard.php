<div class="container" style="padding-top: 40px">
    <div class="card">
        <h1>Selamat Datang di Aplikasi Pengelolahan Kas Masjid Al-Huda Parmahanan</h1>
    </div>
</div>