<?php
namespace App;

class KasKeluar extends DB{
    
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $sql = "SELECT * from kas_keluars";
        $stmt = $this->db->prepare($sql);
        
        $stmt->execute();
        
        $data = [];
        while ($rows = $stmt->fetch()){
            $data[] = $rows;    
        }
    
        return $data;
    } 
    
    public function getKategori($id){
        $sql = "SELECT * FROM kategoris WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row['nama'];
    } 

    public function getUser($id){
        $sql = "SELECT * FROM users WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row['name'];
    } 

    public function insert(){
        $nama = $_POST['nama'];
        $kategori_id = $_POST['kategori_id'];
        $user_id = $_POST['user_id'];
        
        $sql = "INSERT INTO kas_keluars VALUES ('', '$nama', '$kategori_id', '$user_id')";
        $stmt = $this->db->prepare($sql);
     
        $stmt->execute();
    }

    public function edit($id){
        $sql = "SELECT * FROM kas_keluars WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }

    public function update($id){
        $nama = $_POST['nama'];
        $kategori_id = $_POST['kategori_id'];
        $user_id = $_POST['user_id'];
        $sql = "UPDATE kas_keluars SET nama = '$nama', kategori_id = '$kategori_id', user_id = '$user_id' WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function delete(){
        $id = $_POST['id'];
        $sql = "DELETE FROM kas_keluars WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

}